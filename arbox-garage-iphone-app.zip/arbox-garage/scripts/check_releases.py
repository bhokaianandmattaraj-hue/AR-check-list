"""Daily public announcement lead discovery; never treats search hits as confirmed releases."""
import os, re, json, time, urllib.request, urllib.parse, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from supabase import create_client
from pywebpush import webpush

URL=os.environ['SUPABASE_URL']; KEY=os.environ['SUPABASE_SERVICE_ROLE_KEY']
db=create_client(URL,KEY)
queries=[('Porsche','ARBOX Almost Real 1/64 Porsche new release'),('Land Rover','ARBOX Almost Real 1/64 Land Rover Defender new release'),('Porsche','ARBOX RWB Porsche 1/64 chase preorder')]
new=[]
for brand,query in queries:
    url='https://news.google.com/rss/search?q='+urllib.parse.quote(query)+'&hl=en-US&gl=US&ceid=US:en'
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'ARBOXGarageReleaseWatcher/1.0'})
        with urllib.request.urlopen(req,timeout=20) as response: root=ET.fromstring(response.read())
        for item in root.findall('./channel/item')[:15]:
            title=(item.findtext('title') or '').strip();link=(item.findtext('link') or '').strip()
            if not title or not link:continue
            if not re.search(r'ARBOX|Almost Real',title,re.I):continue
            if not re.search(r'Porsche|911|RWB|Land Rover|Defender',title,re.I):continue
            record={'brand':brand,'title':title[:300],'url':link,'status':'TBA / review'}
            existing=db.table('release_leads').select('id').eq('url',link).limit(1).execute().data
            if not existing:
                db.table('release_leads').insert(record).execute();new.append(record)
    except Exception as ex:print('Source failed:',query,str(ex))
    time.sleep(1)
print('New leads:',len(new))
if new and os.getenv('VAPID_PRIVATE_KEY') and os.getenv('VAPID_EMAIL'):
    subs=db.table('push_subscriptions').select('endpoint,subscription').execute().data
    for s in subs:
        try:
            webpush(subscription_info=s['subscription'],data=json.dumps({'title':'ARBOX release radar','body':f'{len(new)} new Porsche / Land Rover announcement lead(s) to review','url':'./'}),vapid_private_key=os.environ['VAPID_PRIVATE_KEY'],vapid_claims={'sub':'mailto:'+os.environ['VAPID_EMAIL']})
        except Exception as ex:print('Push failed:',str(ex))
